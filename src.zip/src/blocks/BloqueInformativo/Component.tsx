import React from 'react'
import RichText from '@/components/RichText'

type Props = {
  svg: string
  titulo: string
  subtitulo?: string
  contenido: any
}

export const BloqueInformativoComponent: React.FC<Props> = ({
  svg,
  titulo,
  subtitulo,
  contenido,
}) => {
  return (
    <div className="bg-white rounded-xl shadow p-6 mb-6 max-w-5xl mx-auto">
      <div className="flex items-start gap-4">
        <div className="text-teal-600" dangerouslySetInnerHTML={{ __html: svg }} />
        <div>
          <h3 className="text-xl font-bold text-teal-700">{titulo}</h3>
          {subtitulo && <p className="text-sm text-gray-500">{subtitulo}</p>}
          <div className="mt-3 text-gray-700 leading-relaxed">
            <RichText data={contenido} />
          </div>
        </div>
      </div>
    </div>
  )
}
