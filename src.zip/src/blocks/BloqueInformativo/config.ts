import {
  lexicalEditor,
  HeadingFeature,
  InlineToolbarFeature,
  FixedToolbarFeature,
  UnorderedListFeature,
} from '@payloadcms/richtext-lexical'
import type { Block } from 'payload'
import SelectSVG from './SelectSVG'

export const BloqueInformativo: Block = {
  slug: 'BloqueInformativo',
  interfaceName: 'BloqueInformativo',
  labels: {
    singular: 'Bloque Informativo',
    plural: 'Bloques Informativos',
  },
  fields: [
    {
      name: 'svg',
      label: 'Ícono SVG',
      type: 'text',
      required: true,
      admin: {
        components: {
          Field: SelectSVG,
        },
      },
    },
    {
      name: 'titulo',
      type: 'text',
      label: 'Título',
      required: true,
    },
    {
      name: 'subtitulo',
      type: 'text',
      label: 'Subtítulo',
    },
    {
      name: 'contenido',
      type: 'richText',
      label: 'Contenido con formato',
      editor: lexicalEditor({
        features: [
          HeadingFeature(),
          InlineToolbarFeature(),
          FixedToolbarFeature(),
          UnorderedListFeature(),
        ],
      }),
    },
  ],
}
